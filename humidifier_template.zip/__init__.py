"""The humidifier template component."""
